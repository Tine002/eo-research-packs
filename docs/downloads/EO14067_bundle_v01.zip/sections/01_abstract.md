
> Stub created by audit. Fill with final content you generated in chat.
> Keep neutral tone; include primary links; 100-word abstract where applicable.
