# Reg/Enforcement timeline (practical impact)

Vertical timeline of major U.S. actions influenced by or contemporaneous with the EO period.

- **2022-03-14** — EO 14067 published; study program begins. <PIN_FR14067>
- **2022–2024** — Agency reports and frameworks roll out (OSTP, Treasury, FSOC, DOJ). <PIN_SERIES>
- **2025-01-31** — EO 14178 published; revokes 14067; new directives. <PIN_FR14178>

For each item: date, who, what, why it matters. Replace `<PIN_…>` with primary links.