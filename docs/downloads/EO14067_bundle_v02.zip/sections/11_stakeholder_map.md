# Stakeholder map

Quote-anchored snapshots to show neutral coverage breadth.

- **Consumer-protection perspective:** <PIN_QUOTE + URL>
- **National-security perspective:** <PIN_QUOTE + URL>
- **Industry/innovation perspective:** <PIN_QUOTE + URL>
- **Climate perspective:** <PIN_QUOTE + URL>

> Keep each quote ≤40 words; prefer agency PDFs over press releases.