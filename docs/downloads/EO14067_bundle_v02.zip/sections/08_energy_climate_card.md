# Energy/climate evidence card

Numbers-only visual card quoting OSTP climate report key figures and uncertainty ranges; no interpretations.

- **Metric 1:** <PIN_VALUE + UNIT + PAGE>  
- **Metric 2:** <PIN_VALUE + UNIT + PAGE>  
- **Recommended actions (verbatim nouns):** <PIN_LIST_FROM_REPORT>  

**Source PDF:** <PIN_OSTP_PDF_LINK>