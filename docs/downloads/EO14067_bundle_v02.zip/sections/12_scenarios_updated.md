# Three-scenario table (updated)

Define Base / High / Low paths after 14178. Each row ties to a report or directive.

| Scenario | Administrative path | Enforcement posture | Market-structure effects | What must change (law vs guidance) | Receipt |
|---|---|---|---|---|---|
| Base | <PIN> | <PIN> | <PIN> | <PIN> | <URL> |
| High | <PIN> | <PIN> | <PIN> | <PIN> | <URL> |
| Low  | <PIN> | <PIN> | <PIN> | <PIN> | <URL> |

> Keep assumptions explicit and receipt-backed; no vibes.
