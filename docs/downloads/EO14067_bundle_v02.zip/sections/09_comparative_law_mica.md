# Comparative law snapshot (EU MiCA vs US path)

**EU MiCA:** short scope and timing; what falls under it; what is deferred. <PIN_EUR_LEX_MICA>

**US (14067→14178):** reports-first approach through 2024; 2025 policy reset and explicit revocation. <PIN_FR_LINKS>

> Purpose is framing, not opinion. Keep to one short paragraph per side with receipts.